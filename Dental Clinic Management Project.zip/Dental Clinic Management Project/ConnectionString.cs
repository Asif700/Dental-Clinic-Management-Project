﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;

namespace Dental_Clinic_Management_Project
{
    class ConnectionString
    {
        public SqlConnection GetCon()
        {
            SqlConnection Con = new SqlConnection();
            Con.ConnectionString = @"Data Source=DESKTOP-SCUS1E8;Initial Catalog=DentalDb;Persist Security Info=True;User ID=sa;Password=12345";
            return Con;
        }
    }
}
